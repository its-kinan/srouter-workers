import{isObject as r}from"./sr-DfF-PdmCtev4.js";function e(n){return r(n)&&"ownerSVGElement"in n}export{e as isSVGElement};
