import{r as e}from"./sr-BaQ6fH3cvQLq.js";var r=e.createContext(!1),o=()=>e.useContext(r);r.Provider;export{o as useIsRestoring};
