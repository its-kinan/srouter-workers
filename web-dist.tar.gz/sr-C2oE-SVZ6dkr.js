import{isPrimaryPointer as t}from"./sr-BtlDhLYC_JZu.js";function i(o){return{point:{x:o.pageX,y:o.pageY}}}const a=o=>r=>t(r)&&o(r,i(r));export{a as addPointerInfo,i as extractEventInfo};
