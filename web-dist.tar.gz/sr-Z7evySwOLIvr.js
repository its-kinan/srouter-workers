/**
 * @license lucide-react v1.31.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase();export{a as toKebabCase};
