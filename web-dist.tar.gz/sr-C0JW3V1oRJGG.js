import{resolveTransition as l}from"./sr-DD8rRqF69Joe.js";function c(e,f){const u=(e==null?void 0:e[f])??(e==null?void 0:e.default)??e;return u!==e?l(u,e):u}export{c as getValueTransition};
