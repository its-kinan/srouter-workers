const s={};export{s as supportsFlags};
