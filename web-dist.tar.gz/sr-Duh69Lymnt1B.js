import{useRenderDialogRoot as r}from"./sr-C8Y8qYe-urRo.js";function e(o){return r("dialog",o)}export{e as DialogRoot};
