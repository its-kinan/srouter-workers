import{__module as r}from"./sr-yeKffFBnme8D.js";import{__require as i}from"./sr-BnrkZA7S0sND.js";var e;function u(){return e?r.exports:(e=1,r.exports=i(),r.exports)}export{u as __require};
