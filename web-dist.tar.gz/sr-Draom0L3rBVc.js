import{r as t}from"./sr-BaQ6fH3cvQLq.js";var o=t.createContext(void 0),r=t.createContext(void 0);export{r as dummyMatchContext,o as matchContext};
