import{fillOffset as e}from"./sr-Bt_ks5wYRfkN.js";function n(t){const f=[0];return e(f,t.length-1),f}export{n as defaultOffset};
