const s=new Set(["none","hidden"]);function t(e,i){return s.has(e)?n=>n<=0?e:i:n=>n>=1?i:e}export{s as invisibleValues,t as mixVisibility};
