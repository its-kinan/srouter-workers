const s=(t,n)=>Math.abs(t-n);function e(t,n){const a=s(t.x,n.x),c=s(t.y,n.y);return Math.sqrt(a**2+c**2)}export{s as distance,e as distance2D};
