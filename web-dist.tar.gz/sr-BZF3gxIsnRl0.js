import o from"./sr-BCHxdBtNPw7H.js";/**
 * @license lucide-react v1.31.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]],t=o("chevron-up",e);export{e as __iconNode,t as default};
