import{r as t}from"./sr-BaQ6fH3cvQLq.js";const r=t.createContext({});export{r as MotionContext};
