import{r as o}from"./sr-BaQ6fH3cvQLq.js";const r=o.createContext({transformPagePoint:t=>t,isStatic:!1,reducedMotion:"never"});export{r as MotionConfigContext};
