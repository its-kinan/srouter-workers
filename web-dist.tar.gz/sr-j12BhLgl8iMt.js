const o="__root__";export{o as rootRouteId};
