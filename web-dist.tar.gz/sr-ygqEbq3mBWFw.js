const i=e=>e!==null;function c(e,{repeat:n,repeatType:l="loop"},o,r=1){const t=e.filter(i),s=r<0||n&&l!=="loop"&&n%2===1?0:t.length-1;return!s||o===void 0?t[s]:o}export{c as getFinalKeyframe};
