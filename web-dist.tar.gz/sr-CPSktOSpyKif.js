import{r as t}from"./sr-BaQ6fH3cvQLq.js";const o=parseInt(t.version,10);function s(r){return o>=r}export{s as isReactVersionAtLeast};
