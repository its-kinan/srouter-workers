import{__module as r}from"./sr-CanrLTR5idg-.js";import{__require as t}from"./sr-CKiSJqqjt-zD.js";var e;function o(){return e?r.exports:(e=1,r.exports=t(),r.exports)}export{o as __require};
