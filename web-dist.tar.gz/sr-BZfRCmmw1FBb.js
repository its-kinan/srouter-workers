import{j as o}from"./sr-BA3axRHy0uMV.js";import{Outlet as t}from"./sr-I1u6p0TOb9FN.js";function m(){return o.jsx(t,{})}export{m as component};
