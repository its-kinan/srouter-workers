import{memoSupports as o}from"./sr-C7l4ZWreXlhJ.js";const i=o(()=>window.ScrollTimeline!==void 0,"scrollTimeline");export{i as supportsScrollTimeline};
