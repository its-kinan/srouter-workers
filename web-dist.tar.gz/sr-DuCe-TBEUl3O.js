function e(){}const t=Object.freeze([]),c=Object.freeze({});export{t as EMPTY_ARRAY,c as EMPTY_OBJECT,e as NOOP};
