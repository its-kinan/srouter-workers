const $=([c,e,i,r])=>`cubic-bezier(${c}, ${e}, ${i}, ${r})`;export{$ as cubicBezierAsString};
