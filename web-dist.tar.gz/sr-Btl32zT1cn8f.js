import{r as t}from"./sr-BaQ6fH3cvQLq.js";const r=t.createContext(null);export{r as PresenceContext};
