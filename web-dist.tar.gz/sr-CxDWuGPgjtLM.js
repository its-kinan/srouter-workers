const e=r=>Array.isArray(r);export{e as isKeyframesTarget};
