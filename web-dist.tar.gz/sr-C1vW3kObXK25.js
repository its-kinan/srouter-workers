import{r as n}from"./sr-BaQ6fH3cvQLq.js";function u(t){const r=n.useRef(null);return r.current===null&&(r.current=t()),r.current}export{u as useConstant};
