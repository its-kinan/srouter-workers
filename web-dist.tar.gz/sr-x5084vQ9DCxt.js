import{isSVGElement as r}from"./sr-C2yI4Dna1uvx.js";function i(t){return r(t)&&t.tagName==="svg"}export{i as isSVGSVGElement};
