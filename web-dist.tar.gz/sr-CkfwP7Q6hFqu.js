import{toCamelCase as t}from"./sr-BgXpRAE129xZ.js";/**
 * @license lucide-react v1.31.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s=a=>{const e=t(a);return e.charAt(0).toUpperCase()+e.slice(1)};export{s as toPascalCase};
