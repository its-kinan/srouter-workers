import{batch as e,createAtom as t}from"./sr-Bv5gooM1Xueg.js";var a=r=>({createMutableStore:t,createReadonlyStore:t,batch:e});export{a as getStoreFactory};
