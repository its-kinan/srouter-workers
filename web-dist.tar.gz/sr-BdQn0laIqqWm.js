import{useMatch as o}from"./sr-B6Xom051h3FE.js";function p(s){const{select:e,...t}=s;return o({...t,select:r=>e?e(r.loaderDeps):r.loaderDeps})}export{p as useLoaderDeps};
