import{GroupAnimation as t}from"./sr-S8XFShHEmHeJ.js";class r extends t{then(n,i){return this.finished.finally(n).then(()=>{})}}export{r as GroupAnimationWithThen};
