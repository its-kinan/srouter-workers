import{createRoute as o}from"./sr-jBEOChpqbpkU.js";function n(r){return e=>{const t=o(e);return t.isRoot=!1,t}}export{n as createFileRoute};
