import{motion as o}from"./sr-wKyHamvPQckX.js";const m=o;export{m as motion};
