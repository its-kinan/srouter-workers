function t(n){n.duration=0,n.type="keyframes"}export{t as makeAnimationInstant};
