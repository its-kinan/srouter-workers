import o from"./sr-BCHxdBtNPw7H.js";/**
 * @license lucide-react v1.31.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["path",{d:"M5 12h14",key:"1ays0h"}]],c=o("minus",e);export{e as __iconNode,c as default};
