const r="Error preloading route! ☝️";export{r as preloadWarning};
