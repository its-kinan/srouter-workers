function n(e,r){if(e&&!r)return e;if(!e&&r)return r;if(e||r)return{...e,...r}}export{n as mergeObjects};
