import{isDragging as e}from"./sr-CUeyCtmwp-OP.js";function l(r){return r==="x"||r==="y"?e[r]?null:(e[r]=!0,()=>{e[r]=!1}):e.x||e.y?null:(e.x=e.y=!0,()=>{e.x=e.y=!1})}export{l as setDragLock};
