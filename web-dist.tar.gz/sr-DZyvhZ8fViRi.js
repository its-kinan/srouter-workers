import{routerContext as t}from"./sr-ELlRVz0SNQg4.js";import{r as o}from"./sr-BaQ6fH3cvQLq.js";function s(r){return o.useContext(t)}export{s as useRouter};
