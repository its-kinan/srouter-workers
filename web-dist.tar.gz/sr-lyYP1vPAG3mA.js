import{j as o}from"./sr-BA3axRHy0uMV.js";import{Outlet as t}from"./sr-I1u6p0TOb9FN.js";function n(){return o.jsx(t,{})}export{n as component};
