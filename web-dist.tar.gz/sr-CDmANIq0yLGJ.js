function n(t){return(t==null?void 0:t.isNotFound)===!0}export{n as isNotFound};
