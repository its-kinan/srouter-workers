import{optimizedAppearDataAttribute as p}from"./sr-CRqgLYNZEIDU.js";function e(t){return t.props[p]}export{e as getOptimisedAppearId};
