import{r as o}from"./sr-BaQ6fH3cvQLq.js";import{mergeClasses as p}from"./sr-C6E5yTEmN5zC.js";import{toKebabCase as f}from"./sr-Z7evySwOLIvr.js";import{toPascalCase as t}from"./sr-CkfwP7Q6hFqu.js";import l from"./sr-D6dgmjR6kEfl.js";/**
 * @license lucide-react v1.31.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const b=(e,a)=>{const r=o.forwardRef(({className:s,...m},c)=>o.createElement(l,{ref:c,iconNode:a,className:p(`lucide-${f(t(e))}`,`lucide-${e}`,s),...m}));return r.displayName=t(e),r};export{b as default};
