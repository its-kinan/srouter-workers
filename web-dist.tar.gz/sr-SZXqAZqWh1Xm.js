import{isObject as t}from"./sr-DfF-PdmCtev4.js";function o(i){return t(i)&&"offsetHeight"in i&&!("ownerSVGElement"in i)}export{o as isHTMLElement};
