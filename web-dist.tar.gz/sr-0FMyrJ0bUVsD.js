const o="0.1.8";export{o as APP_VERSION};
