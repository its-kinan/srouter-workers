import{r as o}from"./sr-BaQ6fH3cvQLq.js";const t={};function f(e,n){const r=o.useRef(t);return r.current===t&&(r.current=e(n)),r}export{f as useRefWithInit};
