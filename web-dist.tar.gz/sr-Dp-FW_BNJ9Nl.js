import{isServer as n}from"./sr-BRaynJRDErPs.js";var v=(()=>{let r=()=>n;return{isServer(){return r()},setIsServer(e){r=e}}})();export{v as environmentManager};
