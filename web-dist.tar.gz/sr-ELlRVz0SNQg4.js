import{r}from"./sr-BaQ6fH3cvQLq.js";var e=r.createContext(null);export{e as routerContext};
