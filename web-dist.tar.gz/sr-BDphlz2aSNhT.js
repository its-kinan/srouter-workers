import{__module as r}from"./sr-BpgyiUhFr-EE.js";import{__require as u}from"./sr-6nqPDK7gt5NA.js";var e;function t(){return e?r.exports:(e=1,r.exports=u(),r.exports)}export{t as __require};
