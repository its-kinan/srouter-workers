function h(e,u){if(e!=null&&e.inherit&&u){const{inherit:f,...c}=e;return{...u,...c}}return e}export{h as resolveTransition};
