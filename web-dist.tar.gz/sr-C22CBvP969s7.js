import{transformPropOrder as t}from"./sr-BV7QdskxcmbL.js";const r=new Set(["width","height","top","left","right","bottom",...t]);export{r as positionalKeys};
