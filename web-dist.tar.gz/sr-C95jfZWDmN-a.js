import{QueryObserver as e}from"./sr-DMtKKvM_D8WX.js";import{useBaseQuery as u}from"./sr-DRkDO28SO5PE.js";function m(r,o){return u(r,e)}export{m as useQuery};
