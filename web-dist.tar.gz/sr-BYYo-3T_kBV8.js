import{createRenderBatcher as e}from"./sr-Dly_yFYAf18M.js";const{schedule:t}=e(queueMicrotask,!1);export{t as microtask};
