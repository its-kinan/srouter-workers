import{r as o}from"./sr-BaQ6fH3cvQLq.js";import{isBrowser as r}from"./sr-Di31y-V0_Fp0.js";const s=r?o.useLayoutEffect:o.useEffect;export{s as useIsomorphicLayoutEffect};
