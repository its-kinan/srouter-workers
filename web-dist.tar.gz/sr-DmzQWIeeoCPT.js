import{resizeElement as o}from"./sr-BJp8uS28JXya.js";import{resizeWindow as i}from"./sr-D8JEpDhjUcnZ.js";function f(e,r){return typeof e=="function"?i(e):o(e,r)}export{f as resize};
