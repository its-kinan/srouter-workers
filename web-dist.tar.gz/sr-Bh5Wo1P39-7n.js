const e=new Set(["opacity","clipPath","filter","transform","backgroundColor"]);export{e as acceleratedValues};
