import{camelToDash as a}from"./sr-CbZs6XphRFiF.js";const t="framerAppearId",e="data-"+a(t);export{e as optimizedAppearDataAttribute,t as optimizedAppearDataId};
