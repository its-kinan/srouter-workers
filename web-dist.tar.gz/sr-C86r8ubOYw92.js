function e(n,o){return typeof n=="function"?n(o):n}export{e as resolveStyle};
