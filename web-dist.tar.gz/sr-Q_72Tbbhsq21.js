import{useMatch as c}from"./sr-B6Xom051h3FE.js";function o(e){return c({...e,select:t=>e.select?e.select(t.context):t.context})}export{o as useRouteContext};
