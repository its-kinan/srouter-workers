import{AnimationFeature as t}from"./sr-DVxQQFeKGb3D.js";import{ExitAnimationFeature as i}from"./sr-BDcKUfiPlncm.js";const o={animation:{Feature:t},exit:{Feature:i}};export{o as animations};
