function t(n,o){return typeof n=="function"?n(o):n}export{t as resolveClassName};
