import{r as t}from"./sr-BaQ6fH3cvQLq.js";const e=t.createContext({}),r=()=>t.useContext(e);export{r as useLucideContext};
