import{addPointerInfo as d}from"./sr-C2oE-SVZ6dkr.js";import{addDomEvent as e}from"./sr-BosEx_Z9Q1RV.js";function f(o,r,t,n){return e(o,r,d(t),n)}export{f as addPointerEvent};
