import"./sr-BaQ6fH3cvQLq.js";import{j as r}from"./sr-BA3axRHy0uMV.js";function i(t){return r.jsx(r.Fragment,{children:t.children})}export{i as SafeFragment};
